    def _get_lock(self, collection: str) -> FileLock:
        """Get or create lock for a collection"""
        if collection not in self._locks:
            lock_file = str(self.base_path / "meta" / f"{collection}.lock")
            self._locks[collection] = FileLock(lock_file)
        return self._locks[collection]