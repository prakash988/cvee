class FileLock:
    """Simple file-based lock for thread-safe operations"""
    
    def __init__(self, lock_file: str):
        self.lock_file = lock_file
        self.lock = threading.Lock()