    def __init__(self, base_path: str = "data", enable_wal: bool = True, cache_max_size: int = 10000):
        # ...
        self._cache = {}  # {collection: {id: data}}
        self._indexes = {}  # {collection: {index_name: {key: [ids]}}}