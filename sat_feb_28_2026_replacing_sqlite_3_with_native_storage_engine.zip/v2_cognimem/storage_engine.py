    def _get_file_path(self, collection: str, doc_id: str) -> Path:
        """Get the file path for a document"""
        collection_path = self._get_collection_path(collection)
        return collection_path / f"{doc_id}.json"