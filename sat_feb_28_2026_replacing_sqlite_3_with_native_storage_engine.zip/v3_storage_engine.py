            # Log to WAL before executing
            if self.enable_wal and self._wal:
                tx_id = self._wal.begin_transaction()
                self._wal.log_operation(tx_id, "put", collection, doc_id, data)
                self._wal.commit(tx_id)
            
            # ... then writes to disk