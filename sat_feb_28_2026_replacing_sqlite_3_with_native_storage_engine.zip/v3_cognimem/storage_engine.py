    def query(self, collection: str, 
              filters: Optional[Dict[str, Any]] = None,
              limit: Optional[int] = None,
              offset: int = 0,
              order_by: Optional[str] = None,
              order_desc: bool = False) -> List[Dict[str, Any]]:
        # Load all documents from collection
        collection_path = self._get_collection_path(collection)
        if not collection_path.exists():
            return []
        
        results = []
        
        for file_path in collection_path.glob("*.json"):
            try:
                with open(file_path, 'r') as f:
                    data = json.load(f)
                
                # Apply filters
                if filters and not self._matches_filters(data, filters):
                    continue
                
                results.append(data)
            except (json.JSONDecodeError, IOError):
                continue