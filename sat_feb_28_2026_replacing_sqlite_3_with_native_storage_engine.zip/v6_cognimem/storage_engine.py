    def put(self, collection: str, doc_id: str, data: Dict[str, Any], 
            indexes: Optional[Dict[str, Any]] = None):
        # ...
        file_path = self._get_file_path(collection, doc_id)
        self._atomic_write(file_path, json.dumps(data, indent=2))