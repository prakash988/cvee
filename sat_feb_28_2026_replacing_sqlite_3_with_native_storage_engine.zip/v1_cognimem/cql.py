    def _execute_select(self, query: SelectQuery) -> List[Dict[str, Any]]:
        """Execute SELECT query"""
        results = self.storage_engine.query(
            query.collection,
            filters=query.where if query.where else None,
            order_by=query.order_by,
            order_desc=query.order_desc,
            limit=query.limit,
            offset=query.offset
        )