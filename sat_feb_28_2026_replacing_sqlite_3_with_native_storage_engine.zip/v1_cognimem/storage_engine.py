class StorageEngine:
    """
    Pure-Python file-based storage engine.
    
    Supports multiple data paradigms through one unified interface:
    - Relational: tables with typed columns, filtering, ordering
    - Document: nested JSON documents, flexible schemas
    - Graph: nodes, edges, traversals
    - Key-value: fast lookup by key
    - Vector-like: embeddings with cosine similarity (pure Python)
    - Time-series: append-only logs with timestamp indexing
    
    Usage:
        engine = StorageEngine("data/")
        engine.put("concepts", concept_id, concept_data)
        concept = engine.get("concepts", concept_id)
        results = engine.query("concepts", filters={"type": "material"})
    """