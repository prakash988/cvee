    def put(self, collection: str, doc_id: str, data: Dict[str, Any], 
            format: Optional[StorageFormat] = None):
        # Use underlying storage engine's put method
        # The storage engine handles JSON serialization
        self._storage.put(collection, doc_id, data)
    
    def get(self, collection: str, doc_id: str) -> Optional[Dict[str, Any]]:
        return self._storage.get(collection, doc_id)