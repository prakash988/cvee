# Your engine already does:
# "What is SS316L?"                              → EXPLAIN intent
# "Find materials with tensile strength above 500" → SEARCH with constraints  
# "Compare SS316L and SS304"                      → COMPARE intent
# "How many concepts do we have?"                  → COUNT intent