        # Load all documents from collection
        collection_path = self._get_collection_path(collection)
        if not collection_path.exists():
            return []
        
        results = []
        
        for file_path in collection_path.glob("*.json"):
            try:
                with open(file_path, 'r') as f:
                    data = json.load(f)