        if order_by:
            results.sort(
                key=lambda x: self._get_nested_value(x, order_by),
                reverse=order_desc
            )