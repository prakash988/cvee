        # Initialize LRU cache manager
        self._cache_manager = CacheManager(default_max_size=cache_max_size)
        
        # Legacy cache reference (for backward compatibility during transition)
        # This will be gradually replaced by _cache_manager
        self._cache = {}  # {collection: {id: data}}