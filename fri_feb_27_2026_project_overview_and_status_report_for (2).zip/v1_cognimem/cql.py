"""
CQL - Concept Query Language

A dual-mode query language for CogniMem:
1. Formal SQL-like syntax (existing)
2. Natural language queries (new)
"""