    """
    THE THINKING DATABASE.

    Entity <=====> CogniMem
          dialogue channel

    CogniMem doesn't wait for queries.
    It THINKS. ANALYZES. COMMUNICATES. ANTICIPATES.
    """